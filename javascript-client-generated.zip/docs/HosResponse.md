# TollGuruCalculator.HosResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | [**HosResponseSummary**](HosResponseSummary.md) |  | [optional] 
**breakPoints** | **[[String]]** |  | [optional] 
**stops** | [**[Stop]**](Stop.md) |  | [optional] 
**data** | [**[HosData]**](HosData.md) |  | [optional] 
