# TollGuruCalculator.RouteResponseSummaryDiffs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cheapest** | **Number** |  | [optional] 
**fastest** | **Number** |  | [optional] 
