# TollGuruCalculator.GeoCordinates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lat** | **Number** | Specify as geo-coordinates (latitude) | [optional] 
**lng** | **Number** | Specify as geo-coordinates (longitude) | [optional] 
