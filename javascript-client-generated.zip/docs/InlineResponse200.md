# TollGuruCalculator.InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | [**SyncResponseSummary**](SyncResponseSummary.md) |  | [optional] 
**route** | [**InlineResponse200Route**](InlineResponse200Route.md) |  | [optional] 
