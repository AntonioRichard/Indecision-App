# TollGuruCalculator.Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **String** | Specify as string, such as Toronto, Ontario, Canada | [optional] 
