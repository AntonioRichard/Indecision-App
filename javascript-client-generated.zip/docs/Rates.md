# TollGuruCalculator.Rates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
