# TollGuruCalculator.OneOfLocation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
