# TollGuruCalculator.HosResponseSummaryTotalDriveDuration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** |  | [optional] 
**value** | **Number** |  | [optional] 
