# TollGuruCalculator.AllOfHereRequestBodyTruck

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
