# TollGuruCalculator.Direction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**position** | [**DirectionPosition**](DirectionPosition.md) |  | [optional] 
**maneuver** | **String** |  | [optional] 
**htmlInstructions** | **String** |  | [optional] 
**distance** | **Number** |  | [optional] 
**duration** | **Number** |  | [optional] 
**note** | **[String]** |  | [optional] 
