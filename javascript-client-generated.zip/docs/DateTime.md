# TollGuruCalculator.DateTime

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
