# TollGuruCalculator.DirectionPosition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latitude** | **Number** |  | [optional] 
**longitude** | **Number** |  | [optional] 
