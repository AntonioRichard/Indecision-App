# TollGuruCalculator.HosResponseSummaryTotalDistance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** |  | [optional] 
**metric** | **Number** |  | [optional] 
**value** | **Number** |  | [optional] 
