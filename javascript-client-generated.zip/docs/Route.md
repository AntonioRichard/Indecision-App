# TollGuruCalculator.Route

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | [**RouteLocation**](RouteLocation.md) |  | [optional] 
