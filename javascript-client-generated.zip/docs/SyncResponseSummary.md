# TollGuruCalculator.SyncResponseSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** |  | [optional] 
**rates** | [**Rates**](Rates.md) |  | [optional] 
**departureTime** | **Number** |  | [optional] 
