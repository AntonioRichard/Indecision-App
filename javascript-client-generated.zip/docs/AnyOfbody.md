# TollGuruCalculator.AnyOfbody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
