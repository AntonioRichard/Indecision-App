# TollGuruCalculator.Cost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fuel** | **Number** |  | [optional] 
**otherCost** | **Number** |  | [optional] 
**tag** | **Number** |  | [optional] 
**cash** | **Number** |  | [optional] 
**licensePlate** | **Number** |  | [optional] 
**creditCard** | **Number** |  | [optional] 
**prepaidCard** | **Number** |  | [optional] 
