# TollGuruCalculator.HosReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rule** | **String** |  | [optional] 
**dutyHoursBeforeEndOfWorkDay** | **Number** |  | [optional] 
**dutyHoursBeforeRestBreak** | **Number** |  | [optional] 
**drivingHoursBeforeEndOfWorkDay** | **Number** |  | [optional] 
**timeRemaining** | **Number** |  | [optional] 

<a name="RuleEnum"></a>
## Enum: RuleEnum

* `60` (value: `"60"`)
* `70` (value: `"70"`)

