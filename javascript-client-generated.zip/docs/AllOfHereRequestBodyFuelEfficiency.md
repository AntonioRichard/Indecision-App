# TollGuruCalculator.AllOfHereRequestBodyFuelEfficiency

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
