# TollGuruCalculator.AllOfHereRequestBodyTo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
