# TollGuruCalculator.OneOfGmapRequestBodyDepartureTime

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
