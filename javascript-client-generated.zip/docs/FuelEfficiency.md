# TollGuruCalculator.FuelEfficiency

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**city** | **Number** |  | [optional] [default to 23.4]
**hwy** | **Number** |  | [optional] [default to 29.25]
**units** | **String** |  | [optional] [default to &#x27;mpg&#x27;]

<a name="UnitsEnum"></a>
## Enum: UnitsEnum

* `mpg` (value: `"mpg"`)
* `kmpl` (value: `"kmpl"`)
* `l100` (value: `"l100"`)

