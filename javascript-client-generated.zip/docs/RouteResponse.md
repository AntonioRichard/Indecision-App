# TollGuruCalculator.RouteResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | [**RouteResponseSummary**](RouteResponseSummary.md) |  | [optional] 
**costs** | [**Cost**](Cost.md) |  | [optional] 
**tolls** | [**[Toll]**](Toll.md) |  | [optional] 
**directions** | [**[Direction]**](Direction.md) |  | [optional] 
**herePath** | **[Number]** |  | [optional] 
**hos** | [**HosResponse**](HosResponse.md) |  | [optional] 
**territoryMileage** | [**TeritoryMielageRes**](TeritoryMielageRes.md) |  | [optional] 
