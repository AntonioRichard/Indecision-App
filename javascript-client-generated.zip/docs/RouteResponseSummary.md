# TollGuruCalculator.RouteResponseSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hasTolls** | **Boolean** |  | [optional] 
**diffs** | [**RouteResponseSummaryDiffs**](RouteResponseSummaryDiffs.md) |  | [optional] 
**url** | **String** |  | [optional] 
**duration** | [**RouteResponseSummaryDuration**](RouteResponseSummaryDuration.md) |  | [optional] 
**distance** | [**RouteResponseSummaryDistance**](RouteResponseSummaryDistance.md) |  | [optional] 
**name** | **String** |  | [optional] 
**note** | **[String]** |  | [optional] 
