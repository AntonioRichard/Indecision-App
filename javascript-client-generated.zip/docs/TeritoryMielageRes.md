# TollGuruCalculator.TeritoryMielageRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
