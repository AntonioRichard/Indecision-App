# TollGuruCalculator.TeritoryMielageResInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**territory** | **Object** |  | [optional] 
**distance** | **Object** |  | [optional] 
**trafficTime** | **String** |  | [optional] 
