# TollGuruCalculator.AsyncResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** |  | [optional] 
**requestId** | **String** |  | [optional] 
**requestedTimestamp** | **String** |  | [optional] 
