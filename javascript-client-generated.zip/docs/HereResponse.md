# TollGuruCalculator.HereResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** |  | [optional] 
**summary** | [**HereResponseSummary**](HereResponseSummary.md) |  | [optional] 
**routes** | [**[RouteResponse]**](RouteResponse.md) | Route information including distance, time, tol | [optional] 
