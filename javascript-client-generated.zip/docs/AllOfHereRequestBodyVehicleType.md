# TollGuruCalculator.AllOfHereRequestBodyVehicleType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
