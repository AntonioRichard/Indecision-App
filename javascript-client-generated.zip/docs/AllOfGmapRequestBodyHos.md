# TollGuruCalculator.AllOfGmapRequestBodyHos

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
