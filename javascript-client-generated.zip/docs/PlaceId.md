# TollGuruCalculator.PlaceId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**placeId** | **String** | Specify as Google Place ID string, such as ChIJlTlXssSPxokROy60gaOlloQ | [optional] 
