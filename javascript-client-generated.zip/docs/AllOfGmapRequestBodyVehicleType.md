# TollGuruCalculator.AllOfGmapRequestBodyVehicleType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
