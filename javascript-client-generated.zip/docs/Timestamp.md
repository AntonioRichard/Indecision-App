# TollGuruCalculator.Timestamp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
