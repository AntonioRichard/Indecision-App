# TollGuruCalculator.HosResponseSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalDriveDuration** | [**HosResponseSummaryTotalDriveDuration**](HosResponseSummaryTotalDriveDuration.md) |  | [optional] 
**totalBreakDuration** | [**HosResponseSummaryTotalDriveDuration**](HosResponseSummaryTotalDriveDuration.md) |  | [optional] 
**totalDuration** | [**HosResponseSummaryTotalDriveDuration**](HosResponseSummaryTotalDriveDuration.md) |  | [optional] 
**totalDistance** | [**HosResponseSummaryTotalDistance**](HosResponseSummaryTotalDistance.md) |  | [optional] 
