# TollGuruCalculator.RouteLocation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lat** | **Number** |  | [optional] 
**lng** | **Number** |  | [optional] 
