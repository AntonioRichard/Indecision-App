# TollGuruCalculator.Body1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestId** | **String** |  | [optional] 
**requestedTimestamp** | **String** |  | [optional] 
