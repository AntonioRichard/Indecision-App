# TollGuruCalculator.SyncResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** |  | [optional] 
**summary** | [**SyncResponseSummary**](SyncResponseSummary.md) |  | [optional] 
**route** | [**SyncResponseRoute**](SyncResponseRoute.md) |  | [optional] 
