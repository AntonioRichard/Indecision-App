# TollGuruCalculator.AllOfHereRequestBodyFrom

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
