# TollGuruCalculator.Location

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
