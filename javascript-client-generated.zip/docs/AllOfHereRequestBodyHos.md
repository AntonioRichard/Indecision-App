# TollGuruCalculator.AllOfHereRequestBodyHos

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
