# TollGuruCalculator.SyncResponseRoute

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hasTolls** | **Boolean** |  | [optional] 
**costs** | [**Cost**](Cost.md) |  | [optional] 
**tolls** | [**[Toll]**](Toll.md) |  | [optional] 
