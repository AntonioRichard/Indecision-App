# TollGuruCalculator.OneOfHereRequestBodyDepartureTime

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
