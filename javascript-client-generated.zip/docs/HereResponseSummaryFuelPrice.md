# TollGuruCalculator.HereResponseSummaryFuelPrice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Number** |  | [optional] 
**currency** | **String** |  | [optional] 
