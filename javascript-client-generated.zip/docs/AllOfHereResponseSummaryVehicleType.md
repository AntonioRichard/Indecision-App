# TollGuruCalculator.AllOfHereResponseSummaryVehicleType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
