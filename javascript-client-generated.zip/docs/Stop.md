# TollGuruCalculator.Stop

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**additionalServices** | **String** |  | [optional] 
**amenities** | **String** |  | [optional] 
**businessesName** | **String** |  | [optional] 
**city** | **String** |  | [optional] 
**contactName** | **String** |  | [optional] 
**fax** | **String** |  | [optional] 
**fuelLanes** | **Number** |  | [optional] 
**highway** | **String** |  | [optional] 
**latitude** | **Number** |  | [optional] 
**longitude** | **Number** |  | [optional] 
**parkingSpots** | **String** |  | [optional] 
**paymentMethods** | **String** |  | [optional] 
**phone1** | **String** |  | [optional] 
**phone2** | **String** |  | [optional] 
**phone3** | **String** |  | [optional] 
**postalCode** | **String** |  | [optional] 
**restIndex** | **String** |  | [optional] 
**showers** | **Number** |  | [optional] 
**state** | **String** |  | [optional] 
**stopId** | **Number** |  | [optional] 
**streetAddress** | **String** |  | [optional] 
**truckServiceBays** | **Number** |  | [optional] 
**type** | **String** |  | [optional] 
**webAddress** | **String** |  | [optional] 
