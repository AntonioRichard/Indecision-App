# TollGuruCalculator.AllOfGmapRequestBodyFuelEfficiency

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
