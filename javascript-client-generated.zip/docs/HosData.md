# TollGuruCalculator.HosData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instruction** | **String** |  | [optional] 
**duration** | [**HosResponseSummaryTotalDriveDuration**](HosResponseSummaryTotalDriveDuration.md) |  | [optional] 
**distance** | [**HosResponseSummaryTotalDistance**](HosResponseSummaryTotalDistance.md) |  | [optional] 
