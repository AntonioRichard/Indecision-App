# TollGuruCalculator.AllOfHereResponseSummaryFuelEfficiency

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
