# TollGuruCalculator.GmapResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** |  | [optional] 
**summary** | [**HereResponseSummary**](HereResponseSummary.md) |  | [optional] 
**routes** | [**[GmapRouteResponse]**](GmapRouteResponse.md) | Route information including distance, time, tol | [optional] 
